#!/bin/bash
echo "Enter a string"
read line
revline=$(echo $line | rev)
if [ $line == $revline ];
then
    echo "string is pallindrome"
else
   echo "string not a pallindrome"
fi;
