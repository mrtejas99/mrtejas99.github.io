#!/bin/bash
echo "menu"
echo "1. display calander"
echo "2. display date and time"
echo "3. display current username"
echo "4. display terminal number"
echo "5. exit"
read choice
case "$choice" in
    1)echo "calender:$(cal)";;
    2)echo "date and time:$(date)";;
    3)echo "current user:$(who)";;
    4)echo "terminal number:$(who -lu)";;
    5)echo "exit"
esac
