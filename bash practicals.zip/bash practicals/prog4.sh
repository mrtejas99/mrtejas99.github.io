#!/bin/sh
flag=0
echo "enter range"
read range
echo "1 is prime"
echo "2 is prime"
for ((i=3;i<=range;i++))
	do
	for ((j=i-1;j>=2;j--))
	do
                x=$(($i%$j))
		if [ $x -ne 0 ];
		then
			flag=1
		else
		        flag=0
                        break;
		fi;
        done
		if [ $flag -eq 1 ];
		then
		echo "$i is prime"
		else
		echo "$i is not prime"	
		fi;
	
done
		

	
