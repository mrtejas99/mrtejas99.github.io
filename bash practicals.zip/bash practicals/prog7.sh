#!/bin/bash
echo "Enter a string"
read line
len=${#line}
flag=1
for((i=0;i<=len/2;i++))
do
c1="${line:$i:1}"
c2="${line:$len-$i-1:1}"
if [ $c1 != $c2 ];
then 
flag=0
echo "not palindrome"
break
fi
done
if (( $flag == 1 ));
then
        echo "palindrome"
fi

